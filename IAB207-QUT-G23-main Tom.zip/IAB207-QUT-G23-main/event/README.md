# IAB207-QUT-G23

# REQUIRES

#DB browser SQLite
#Python 3.10
#pip install flask
#pip install werkzeug
#pip install flask-wtf
#pip install bootstrap-flask
#pip install flask-sqlalchemy
#pip install flask-login
#pip install email-validator
#pip install flask-bcrypt
